The responsive layout structure is adapted from the AdaptiveTheme project by
Jeff Burnz. https://drupal.org/project/adaptivetheme Many of the comments are left intact
and that is where the "AT" comes from that is seen throughout.

AT Page Layout Plugins
----------------------

These plugins provide the main page layout settings and CSS. Each plugin
defines a layout "method" which is basically CSS that sets the position and
bebaviour of the columns, i.e. the two sidebars and the main content column.

For exstenive docs on the structure and syntax for a plugin see the
"three_col_grail" page layout, after reading this you should be able to make
your own layout plugin.
